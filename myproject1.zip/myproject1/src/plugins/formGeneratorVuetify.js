import Vue from 'vue'
import FormGeneratorVuetify from 'form-generator-vuetify'

Vue.use(FormGeneratorVuetify)

// Add Our GraphQL CLient
// export const graphqlFormClient = graphqlClient
