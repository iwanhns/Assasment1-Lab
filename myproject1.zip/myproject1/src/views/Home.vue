<template>
  <div class="home">
    <img alt="Vue logo" src="../assets/logo1.png">
     <div id="overviews" class="section lb">
            <div class="container">
                <div class="section-title row text-center">
                    <div class="col-md-8 offset-md-2">
                        <h3>Tentang</h3>
                        <p class="lead">ESQ Business School adalah satu-satunya sekolah bisnis di Indonesia berbasis pendidikan karakter yang mendidik para mahasiswanya agar mampu mengelola BISNIS secara profesional dan menguasai TEKNOLOGI informasi sesuai perkembangan zaman.</p><br>
                    </div>
                </div><!-- end title -->

                <div class="row align-items-center">
                    <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
                        <div class="message-box">
                            <h3>Sejarah Kita</h3>
                            <p>ESQBS didirikan dan dipimpin oleh tokoh pendidikan Prof. Ir. Surna Tjahya Djajadiningrat, M.Sc., Ph.D (hingga 2014) serta tokoh di bidang pendidikan karakter DR.HC. Ary Ginanjar Agustian. ESQBS adalah kampus modern yang merupakan sarana untuk mempersiapkan siswa dalam menghadapi tantangan besar dan menjadi generasi pemimpin berikutnya.</p><br>

                            <b><p> Kampus ESQBS menyelenggarakan program pendidikan sarjana (S1), yaitu :</p></b>
                                <li><i class="fa fa-check-square-o"></i> Program studi Manajemen Bisnis </li>
                                <li><i class="fa fa-check-square-o"></i> Program studi Sistem Informasi Bisnis </li>
                                <li><i class="fa fa-check-square-o"></i> Program studi Ilmu Komputer</li>
                                <li><i class="fa fa-check-square-o"></i> Program studi Second Generation</li>
                        </div><!-- end messagebox -->
                    </div><!-- end col -->                   
                </div><br>

                <div class="row align-items-center">
                    <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
                        <div class="message-box">
                            <h3>Beasiswa S2 Computer Science Tokyo Institute of Technology JOB VACANCY  22 Mar 2018 Lowongan Pekerjaan Database Administrators</h3>
                            <p>Yanti Alumni ESQ BS : "Untuk beasiswa, beruntung aku bisa menjadi salah satu penerima beasiswa INPEX Scholarship Foundation yang hanya diberikan kepada tiga orang setiap tahunnya. Aku sudah mengetahui informasi tentang beasiswa ini di beberapa semester terakhir kuliahku dari beberapa grup facebook yang aku ikuti, tapi aku tidak pernah menyangka aku bisa mendapatkan beasiswa ini. Bener-bener tidak menyangka. Tapi jangan berfikir kalau aku adalah orang yang cerdas dengan IPK menjulang tinggi atau jadi mahasiswa berprestasi di Kampus. Ada beberapa hal yang aku yakini menjadi alasan mengapa aku diterima beasiswa ini"</p>
                        </div><!-- end messagebox -->
                    </div><!-- end col -->
                </div><!-- end row -->
            </div><!-- end container -->
        </div><!-- end section -->

  </div>
</template>

	
